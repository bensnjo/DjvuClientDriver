﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace djvu.models
{
    internal class Activation
    {
        public string Serial_Number { get; set; }
        public string status { get; set; }
       
    }
}
