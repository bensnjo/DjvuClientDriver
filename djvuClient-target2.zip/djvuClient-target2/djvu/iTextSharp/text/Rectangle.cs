﻿using System.util;

namespace djvu.iTextSharp.text
{
    internal class Rectangle : RectangleJ
    {
        public Rectangle(float x, float y, float width, float height) : base(x, y, width, height)
        {
        }
    }
}