﻿namespace djvu.iTextSharp.text.pdf.parser
{
    internal class PdfRenderContext
    {
        private object value;

        public PdfRenderContext(object value)
        {
            this.value = value;
        }
    }
}